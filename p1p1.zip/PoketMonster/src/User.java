import java.util.*;

public class User {
	String name = "지우";

	Scanner sc = new Scanner(System.in);
	Monster[] monster = Monster.nameArr;
	Monster getpoketmon;
	String getPoket;
	Random rd = new Random();
	int monsterafterhp = 0;
	int poketafterhp = 0;
	int afterstep =0;
	
	
	
	
	
	public void information() {
		System.out.println("현재 고를수있는 포켓몬입니다. :");
		System.out.println("0 : 피카츄, 1 : 파이리, 2: 꼬부기, 3: 이상해씨");
		
		for(Monster mon : monster) {
			System.out.println(mon);
		}	
		
	}
	
	public void getPoketmon() {
		int input = sc.nextInt();
		System.out.println(input);
		
		getpoketmon = monster[input];
		System.out.println("선택하신 포켓몬은 " + getpoketmon.name + "입니다.");
	}
	
	public void walking(int walk) {
		
		System.out.println("");
		// 걷다가
		
	}
	
	
	
	
	public void monsterAttack (Monster mon) {
		// 필드에 몬스터 생성 후 싸우기
		//속성별 데미지 반감
	
		
		
		
		
		
		
		
		if (getpoketmon.hp == 0) {
			System.out.println("포켓몬(몬스터)가(이) 죽었습니다.\n");
		}else {
			 System.out.printf("%s가 %s 의 데미지로 공격하였습니다.\n",mon.name,mon.damage);
			 poketafterhp = getpoketmon.hp-mon.damage;
			 
			
		}
		System.out.printf("현재 %s의 체력이 %s 남았습니다.\n", mon.name, monsterafterhp);
		getpoketmon.hp = monsterafterhp;
		
		
		
	
	}	
	
	public void userAttack (Monster mon) {
		// 필드에 몬스터 생성 후 싸우기
		//속성별 데미지 반감
	
		if (getpoketmon.hp==0) {
			System.out.printf("%s가(이) 죽었습니다.",getpoketmon.name);
		}else {
			 System.out.printf("%s이(가) %s 의 데미지로 공격하였습니다.\n",getpoketmon.name,getpoketmon.damage);
			 poketafterhp = getpoketmon.hp-getpoketmon.damage;
			 
			
		}
		System.out.printf("현재 %s의 체력이 %s 남았습니다.\n", getpoketmon.name, poketafterhp);
		getpoketmon.hp = poketafterhp;
		
		
		
	
	}
	
	public void walk(int step) {

		System.out.println("몇보 걸으시겠습니까 : \n");
		step = sc.nextInt();
		afterstep += step;
		for (int i = 1; i <= step; i++) {
			System.out.println(this.name + "가 걷습니다." + step + "보");
			System.out.println(afterstep);
			if (afterstep % 5 == 0 ) {
				System.out.println("포켓몬을 만났습니다");
				break;		
			} 
			
			System.out.println("더걸어주세요");
			
			
		} 	
		
		System.out.printf("현재 %s보 걸었습니다 \n",afterstep);
		

	}


	@Override
	public String toString() {
		return "User [name=" + name + "]";
	}


}
