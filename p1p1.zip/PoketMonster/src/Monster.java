
public class Monster  {
	String name  ;
	int hp;
	int damage;	
	String kind;
	int experience = 10;
	
	static Monster pikachu = new Monster("피카츄",30, 10, "전기");
	static Monster charmander= new Monster("파이리",30, 10, "불");
	static Monster squirtle= new Monster("꼬부기",30, 10, "물");
	static Monster bulbasaur = new Monster("이상해씨",30, 10, "풀");
	
	static Monster[] nameArr = {pikachu,charmander,squirtle,bulbasaur};
	
	public Monster(String name, int hp, int damage, String kind) {
		
		this.name = name;
		this.hp = hp;
		this.damage = damage;
		this.kind = kind;
		
		
	}

	
	public void recovery() {
		
	}

	
	
	

	@Override
	public String toString() {
		return "Monster [name=" + name + ", hp=" + hp + ", 데미지=" + damage + ", 속성=" + kind + ", 경험치="
				+ experience +"]";
	}

	
	
	
	
}

