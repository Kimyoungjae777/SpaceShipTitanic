
public class RecoveryMedicine {
	int hp = 10;
	
}
