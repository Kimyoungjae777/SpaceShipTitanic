import java.util.*;

public class Main {
	public static void main(String[] args) {
		Field filed = new Field();
		User usr = new User();
		Monster[] monster = Monster.nameArr;
		Random rd = new Random();
		Monster mons ;
//		//필드에 생성된 몬스터 확인하기.
//		Scanner sc = new Scanner(System.in);
//		
//		filed.fieldMonster();
		
		System.out.println("어서오세요 포켓몬월드입니다. \n");
		System.out.println("====================");
		System.out.println("포켓몬을 선택해주세요");
		// 고를수있는 포켓몬 알려주기
		usr.information();
		usr.getPoketmon();
		//길을 걷기
		mons = monster[rd.nextInt(3)];
		System.out.printf("필드에 몬스터 %s 가 나왔습니다.\n", mons.name);
		usr.monsterAttack(mons);
		usr.userAttack(mons);
		usr.walk(10);
		
		
		
		//걸을때 몇보를 걸어가서 만나게 할것인가를 정해야함.
		//
		
		
		
		
		
		// 포켓몬선택하여 가지기
		
		
		
		
		
		
		
		
		
		
	}
}
